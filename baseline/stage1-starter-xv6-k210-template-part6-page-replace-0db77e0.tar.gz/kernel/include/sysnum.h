#ifndef __SYSNUM_H
#define __SYSNUM_H

// System call numbers
#define SYS_fork         1
#define SYS_exit         2
#define SYS_wait         3
#define SYS_pipe         4
#define SYS_read         5
#define SYS_kill         6
#define SYS_exec         7
#define SYS_fstat        8
#define SYS_chdir        9
#define SYS_dup         10
#define SYS_getpid      11
#define SYS_sbrk        12
#define SYS_sleep       13
#define SYS_uptime      14
#define SYS_open        15
#define SYS_write       16
#define SYS_remove      17
#define SYS_trace       18
#define SYS_sysinfo     19
#define SYS_mkdir       20
#define SYS_close       21
#define SYS_test_proc   22
#define SYS_dev         23
#define SYS_readdir     24
#define SYS_getcwd      25
#define SYS_rename      26
#define SYS_shutdown    54320
#define SYS_dup2        54321
// #define SYS_set_timeslice   54322
// #define SYS_set_priority    54323
// #define SYS_get_priority    54324
// #define SYS_getpgcnt    54325
// #define SYS_getprocsz   54326
#define SYS_mmap    54330
#define SYS_munmap  54331
#define SYS_set_max_page_in_mem 54332
#define SYS_get_swap_count  54333
#define SYS_lru_access_notify 54334

#endif